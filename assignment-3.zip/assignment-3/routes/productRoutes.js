const express = require('express');
const c = require('../controllers/productController');
const { validateObjectId } = require('../middleware/errorMiddleware');

const router = express.Router();

// Reports (must be declared before "/:id")
router.get('/reports/low-stock', c.lowStockReport);
router.get('/reports/category-summary', c.categorySummary);

router.route('/').get(c.getProducts).post(c.createProduct);

router.patch('/:id/stock', validateObjectId, c.adjustStock);

router
  .route('/:id')
  .get(validateObjectId, c.getProductById)
  .put(validateObjectId, c.updateProduct)
  .delete(validateObjectId, c.deleteProduct);

module.exports = router;
