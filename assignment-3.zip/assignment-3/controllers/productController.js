const Product = require('../models/Product');

const httpError = (statusCode, message) => {
  const e = new Error(message);
  e.statusCode = statusCode;
  return e;
};

// POST /api/products
exports.createProduct = async (req, res, next) => {
  try {
    const product = await Product.create(req.body);
    res.status(201).json({ success: true, data: product });
  } catch (err) {
    next(err);
  }
};

// GET /api/products?category=&minPrice=&maxPrice=&inStock=&search=&sort=&page=&limit=
exports.getProducts = async (req, res, next) => {
  try {
    const { category, minPrice, maxPrice, inStock, search, sort, page = 1, limit = 10 } = req.query;

    const filter = {};
    if (category) filter.category = category.toLowerCase();
    if (minPrice || maxPrice) {
      filter.price = {};
      if (minPrice) filter.price.$gte = Number(minPrice);
      if (maxPrice) filter.price.$lte = Number(maxPrice);
    }
    if (inStock === 'true') filter.quantity = { $gt: 0 };
    if (inStock === 'false') filter.quantity = 0;
    if (search) filter.name = { $regex: search.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), $options: 'i' };

    // sort=price,-quantity  -> { price: 1, quantity: -1 }
    const sortBy = sort ? sort.split(',').join(' ') : '-createdAt';

    const pageNum = Math.max(parseInt(page, 10) || 1, 1);
    const limitNum = Math.min(Math.max(parseInt(limit, 10) || 10, 1), 100);

    const [total, products] = await Promise.all([
      Product.countDocuments(filter),
      Product.find(filter)
        .sort(sortBy)
        .skip((pageNum - 1) * limitNum)
        .limit(limitNum),
    ]);

    res.json({
      success: true,
      count: products.length,
      total,
      page: pageNum,
      totalPages: Math.ceil(total / limitNum),
      data: products,
    });
  } catch (err) {
    next(err);
  }
};

// GET /api/products/:id
exports.getProductById = async (req, res, next) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) throw httpError(404, 'Product not found');
    res.json({ success: true, data: product });
  } catch (err) {
    next(err);
  }
};

// PUT /api/products/:id  (details update)
exports.updateProduct = async (req, res, next) => {
  try {
    const product = await Product.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    });
    if (!product) throw httpError(404, 'Product not found');
    res.json({ success: true, data: product });
  } catch (err) {
    next(err);
  }
};

// PATCH /api/products/:id/stock  body: { type: "restock" | "sale", quantity: n }
exports.adjustStock = async (req, res, next) => {
  try {
    const { type, quantity } = req.body;
    const qty = Number(quantity);

    if (!['restock', 'sale'].includes(type)) {
      throw httpError(400, 'type must be "restock" or "sale"');
    }
    if (!Number.isInteger(qty) || qty <= 0) {
      throw httpError(400, 'quantity must be a positive integer');
    }

    let product;
    if (type === 'restock') {
      product = await Product.findByIdAndUpdate(req.params.id, { $inc: { quantity: qty } }, { new: true });
    } else {
      // Atomic: only decrement if enough stock exists (prevents negative stock / race conditions)
      product = await Product.findOneAndUpdate(
        { _id: req.params.id, quantity: { $gte: qty } },
        { $inc: { quantity: -qty } },
        { new: true }
      );
      if (!product) {
        const exists = await Product.exists({ _id: req.params.id });
        if (!exists) throw httpError(404, 'Product not found');
        throw httpError(400, 'Insufficient stock for this sale');
      }
    }

    if (!product) throw httpError(404, 'Product not found');
    res.json({ success: true, message: `Stock ${type} successful`, data: product });
  } catch (err) {
    next(err);
  }
};

// DELETE /api/products/:id
exports.deleteProduct = async (req, res, next) => {
  try {
    const product = await Product.findByIdAndDelete(req.params.id);
    if (!product) throw httpError(404, 'Product not found');
    res.json({ success: true, message: 'Product deleted', data: product });
  } catch (err) {
    next(err);
  }
};

// GET /api/products/reports/low-stock  (quantity <= reorderLevel)
exports.lowStockReport = async (req, res, next) => {
  try {
    const items = await Product.aggregate([
      { $match: { $expr: { $lte: ['$quantity', '$reorderLevel'] } } },
      {
        $project: {
          name: 1,
          sku: 1,
          category: 1,
          quantity: 1,
          reorderLevel: 1,
          shortage: { $subtract: ['$reorderLevel', '$quantity'] },
        },
      },
      { $sort: { quantity: 1 } },
    ]);
    res.json({ success: true, count: items.length, data: items });
  } catch (err) {
    next(err);
  }
};

// GET /api/products/reports/category-summary
exports.categorySummary = async (req, res, next) => {
  try {
    const summary = await Product.aggregate([
      {
        $group: {
          _id: '$category',
          totalProducts: { $sum: 1 },
          totalQuantity: { $sum: '$quantity' },
          totalValue: { $sum: { $multiply: ['$price', '$quantity'] } },
          avgPrice: { $avg: '$price' },
          minPrice: { $min: '$price' },
          maxPrice: { $max: '$price' },
        },
      },
      {
        $project: {
          _id: 0,
          category: '$_id',
          totalProducts: 1,
          totalQuantity: 1,
          totalValue: { $round: ['$totalValue', 2] },
          avgPrice: { $round: ['$avgPrice', 2] },
          minPrice: 1,
          maxPrice: 1,
        },
      },
      { $sort: { totalValue: -1 } },
    ]);
    res.json({ success: true, count: summary.length, data: summary });
  } catch (err) {
    next(err);
  }
};
